import Router from './routes/AllRoutes'

function App() {

  return (
    <>
      <Router />
    </>
  )
}

export default App
