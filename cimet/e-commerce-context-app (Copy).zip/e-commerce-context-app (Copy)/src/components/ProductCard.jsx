import React from 'react'

const ProductCard = ({ data }) => {
    return (
        <div>
            <img style={{
                width: "100px", height: "100px"
            }}
                src={data.image} alt="" />
            <h3>{data.title}</h3>
            <p>{data.price}</p>
        </div>
    )
}

export default ProductCard
