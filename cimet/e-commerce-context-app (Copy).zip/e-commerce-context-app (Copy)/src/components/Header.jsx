import React from 'react'
import { Link } from 'react-router-dom'

const Header = () => {
    return (
        <div>
            <div>
                <h1><Link to="/">ECommerce</Link></h1>
            </div>
            <div>
                <Link to="/products">Products</Link>
                <Link to="/cart">Carts</Link>
                <Link to="/blogs">Blogs</Link>
            </div>
        </div >
    )
}

export default Header
