import React from 'react'
import { useLoaderData } from 'react-router-dom';
import ProductCard from '../components/ProductCard';

const Products = () => {
    const data = useLoaderData();
    return (
        <div>
            {data.map((el) => {
                return <ProductCard data={el} />
            })}
        </div>
    )
}

export default Products