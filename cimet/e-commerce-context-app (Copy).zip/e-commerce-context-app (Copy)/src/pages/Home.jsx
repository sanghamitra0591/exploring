import React from 'react'
import { useLoaderData } from 'react-router-dom'
import ProductCard from '../components/ProductCard';

const Home = () => {
    const data = useLoaderData();
    return (
        <div>
            <h1>Featured Products</h1>
            {data.map((el) => {
                return <ProductCard data={el} />
            })}
        </div>
    )
}

export default Home
