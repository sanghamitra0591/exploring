const { createContext } = require("react");

const CartContext = createContext();

const CartContextProvider = () => {
    return <CartContext.Provider>{children}</CartContext.Provider>
}

export default CartContextProvider;