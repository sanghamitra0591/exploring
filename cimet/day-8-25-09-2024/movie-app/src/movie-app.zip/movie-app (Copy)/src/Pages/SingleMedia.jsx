import React, { useContext, useEffect, useState } from 'react'
import { MediaContext } from '../Context/MediaContext';
import "../Styles/SingleMedia.css";
import { useParams } from 'react-router-dom';

const SingleMedia = () => {
    const { singleMediaData, searchSingleMedia } = useContext(MediaContext);
    const id = useParams().id;
    const media = JSON.parse(localStorage.getItem("mediaType"));
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        searchSingleMedia(media, id);
    }, [])
    const Id = setTimeout(() => {
        setLoading(false);
        if (Id) {
            clearTimeout(Id);
        }
    }, 600);

    if (loading) {
        return (
            <div className="loading">
                <img
                    src="https://bandhanbank.com/themes/customs/bandhan_bank/images/branch-locator/loadersr.gif"
                    alt="No Results Found"
                />
            </div>
        );
    }

    const baseUrl = "https://image.tmdb.org/t/p/";
    const size = "original";
    const imageSrc = baseUrl + size + singleMediaData.poster_path;
    return (
        <div className='singleMediaWrapper'>
            <div>
                <div>
                    <img src={imageSrc || "https://movix-app-murex.vercel.app/assets/no-poster-4xa9LmsT.png"
                    }
                        alt="movieImage"
                        onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = "https://movix-app-murex.vercel.app/assets/no-poster-4xa9LmsT.png";
                        }} />
                </div>
                <div>
                    <h2>{singleMediaData.title || singleMediaData.name}</h2>
                    <p>Genre : {singleMediaData.genres?.map((el) => <span key={el.id}>{el.name} </span>)}</p>
                    <h3>Overview</h3>
                    <p>{singleMediaData.overview || "Lorem ipsum dolor sit amet. Sit nobis quasi vel deserunt consectetur eos blanditiis veritatis. Sit quidem dolores sed maiores veritatis est possimus dolore qui asperiores mollitia et repellendus quia et tempora ipsa nam Quis sint. Hic architecto dolorem aut consequatur animi id "}</p>
                    <p>Language : <span>{"English" || singleMediaData.original_language}</span></p>
                    <p>Status : <span>Released</span></p>
                    <p>Release Date: <span>{singleMediaData.release_date || singleMediaData.first_air_date}</span></p>
                </div>
            </div>
        </div >
    )
}

export default SingleMedia
