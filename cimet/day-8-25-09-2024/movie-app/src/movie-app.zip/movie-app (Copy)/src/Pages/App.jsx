import Footer from '../Components/Footer'
import Navbar from '../Components/Navbar'
import MainRoute from '../Routes/MainRoute'
import "../Styles/App.css"

const App = () => {
    return (
        <div className='bodyWrapper'>
            <Navbar />
            <MainRoute />
            <Footer />
        </div>
    )
}

export default App
