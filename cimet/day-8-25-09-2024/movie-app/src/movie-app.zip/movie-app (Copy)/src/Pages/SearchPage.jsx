// SearchPage.jsx
import { useContext, useEffect, useState } from "react";
import { MediaContext } from "../Context/MediaContext";
import SingleMediaCard from "../Components/SingleMediaCard";
import "../Styles/SearchPage.css";
import { useParams } from "react-router-dom";

const SearchPage = () => {
    const baseUrl = "https://image.tmdb.org/t/p/";
    const size = "w200";
    const { combinedResults, loading } = useContext(MediaContext);
    const query = useParams().query;
    return (
        <div className="searchPageWrapper">
            {loading && < div className="loading"><img src="https://bandhanbank.com/themes/customs/bandhan_bank/images/branch-locator/loadersr.gif" alt="No Results Found" /></div>}
            {combinedResults.length > 0 ? (
                <div>
                    <h2>Search Results for : {query}</h2>
                    <div className="searchPageContainer">
                        {combinedResults.map((el) => (
                            <SingleMediaCard
                                key={el.id}
                                el={el}
                                imageSrc={
                                    baseUrl +
                                    size +
                                    (el.mediaType === "movie" ? el.poster_path : el.backdrop_path)
                                }
                            />
                        ))}
                    </div>
                </div>
            ) : (
                <div className="noResults"><img src="https://ottcloudserver.com/assets/templates/labflix/images/no-results.png" alt="No Results Found" /></div>
            )
            }
        </div >
    );
};

export default SearchPage;
