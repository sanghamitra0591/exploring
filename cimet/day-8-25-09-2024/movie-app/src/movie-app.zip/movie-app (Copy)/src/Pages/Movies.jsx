import { useContext, useEffect, useState } from "react";
import { MediaContext } from "../Context/MediaContext";
import SingleMediaCard from "../Components/SingleMediaCard";
import "../Styles/Movies.css";

const Movies = () => {
    const baseUrl = "https://image.tmdb.org/t/p/";
    const size = "w200";
    const { allMovies, setPageMovies, hasMoreMovies, loading, fetchMovies } =
        useContext(MediaContext);

    const [selectedGenre, setSelectedGenre] = useState("");
    const [sortOrder, setSortOrder] = useState("");

    const handleScroll = () => {
        if (
            window.innerHeight + window.scrollY >= document.body.offsetHeight &&
            hasMoreMovies
        ) {
            setPageMovies((prevPage) => prevPage + 1);
        }
    };

    const handleGenreChange = (e) => {
        const genreId = e.target.value;
        setSelectedGenre(genreId);
        setPageMovies(1);
        fetchMovies(1, genreId, sortOrder);
    };

    const handleSortChange = (e) => {
        const order = e.target.value;
        setSortOrder(order);
        setPageMovies(1);
        fetchMovies(1, selectedGenre, order);
    };

    useEffect(() => {
        window.addEventListener("scroll", handleScroll);
        return () => {
            window.removeEventListener("scroll", handleScroll);
        };
    }, [hasMoreMovies]);

    if (loading) {
        return (
            <div className="loading">
                <img
                    src="https://bandhanbank.com/themes/customs/bandhan_bank/images/branch-locator/loadersr.gif"
                    alt="No Results Found"
                />
            </div>
        );
    }

    if (allMovies.length === 0) {
        return (
            <div className="noResults"><img src="https://ottcloudserver.com/assets/templates/labflix/images/no-results.png" alt="No Results Found" /></div>
        );
    }

    return (
        <div className="movieWrapper">
            <div className="filterContainer">
                <p>Explore Movies</p>
                <div className="selectDiv">
                    <select onChange={handleGenreChange} value={selectedGenre}>
                        <option value="">Select Genre</option>
                        <option value="28">Action</option>
                        <option value="12">Adventure</option>
                        <option value="35">Comedy</option>
                        <option value="80">Crime</option>
                        {/* Add more genres as needed */}
                    </select>
                    <select onChange={handleSortChange} value={sortOrder}>
                        <option value="">Sort By</option>
                        <option value="popularity.asc">Popularity: Low to High</option>
                        <option value="popularity.desc">Popularity: High to Low</option>
                        <option value="vote_average.asc">Rating: Low to High</option>{" "}
                        {/* Added for rating */}
                        <option value="vote_average.desc">Rating: High to Low</option>{" "}
                        {/* Added for rating */}
                    </select>
                </div>
            </div>
            <div className="movieContainer">
                {allMovies.length > 0 &&
                    allMovies.map((el) => (
                        <SingleMediaCard
                            key={el.id}
                            el={el}
                            imageSrc={baseUrl + size + el.poster_path}
                        />
                    ))}
            </div>
            {hasMoreMovies && <div>Loading more movies...</div>}
        </div>
    );
};

export default Movies;