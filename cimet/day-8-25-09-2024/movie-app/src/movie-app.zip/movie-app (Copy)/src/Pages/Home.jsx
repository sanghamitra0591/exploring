import { useContext, useState } from "react";
import "../Styles/Home.css";
import { MediaContext } from "../Context/MediaContext";
import MediaCarousal from "../Components/MediaCarousal";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();
  const {
    banner,
    trendingDay,
    trendingWeek,
    popularDay,
    popularWeek,
    topRatedDay,
    topRatedWeek,
    searchMedia
  } = useContext(MediaContext);

  const [searchInput, setSearchInput] = useState("");
  const baseUrl = "https://image.tmdb.org/t/p/";
  const size = "original";
  const bannerImage = baseUrl + size + banner.backdrop_path;

  const handleInput = (e) => {
    const value = e.target.value;
    setSearchInput(value);
  };

  const handleSearch = () => {
    if (searchInput.trim()) {
      searchMedia(searchInput);
      setSearchInput("");
      console.log(`/search/${searchInput}`)
      navigate(`/search/${searchInput}`);
    }
  };

  return (
    <div className="HomeWrapper">
      <div className="bannerDiv" style={{
        backgroundImage: `url(${bannerImage})`,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        backgroundBlendMode: 'overlay'
      }}>
        <div>
          <h1>Welcome.</h1>
          <h3> Millions of movies, TV shows and people to discover. Explore now. </h3>
          <div>
            <input
              value={searchInput}
              onChange={handleInput}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch();
                }
              }}
              type="text"
              placeholder="Search for a movie or TV show...."
            />
            <button onClick={handleSearch}>Search</button>
          </div>
        </div>
      </div>
      <div className="contentDiv">
        <MediaCarousal dayData={trendingDay} weekData={trendingWeek} title="Trending" day="Day" week="Week" />
        <MediaCarousal dayData={popularDay} weekData={popularWeek} title="Popular" day="Movies" week="TV Shows" />
        <MediaCarousal dayData={topRatedDay} weekData={topRatedWeek} title="Top Rated" day="Movies" week="TV Shows" />
      </div>
    </div>
  );
};

export default Home;