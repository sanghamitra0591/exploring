import { useContext, useEffect, useState } from "react";
import { MediaContext } from "../Context/MediaContext";
import SingleMediaCard from "../Components/SingleMediaCard";
import "../Styles/TvShows.css";

const TvShows = () => {
    const baseUrl = "https://image.tmdb.org/t/p/";
    const size = "w200";
    const {
        allTvShows,
        setPageTVShows,
        hasMoreTVShows,
        loading,
        fetchTVShows
    } = useContext(MediaContext);

    const [selectedGenre, setSelectedGenre] = useState("");
    const [sortOrder, setSortOrder] = useState("");

    const handleScroll = () => {
        if (window.innerHeight + window.scrollY >= document.body.offsetHeight && hasMoreTVShows) {
            setPageTVShows(prevPage => prevPage + 1);
        }
    };

    const handleGenreChange = (e) => {
        setSelectedGenre(e.target.value);
        fetchTVShows(1, e.target.value, sortOrder); // Fetch TV shows when genre changes
    };

    const handleSortChange = (e) => {
        setSortOrder(e.target.value);
        fetchTVShows(1, selectedGenre, e.target.value); // Fetch TV shows when sort order changes
    };

    useEffect(() => {
        window.addEventListener('scroll', handleScroll);
        return () => {
            window.removeEventListener('scroll', handleScroll);
        };
    }, [hasMoreTVShows]);

    if (loading) {
        return (
            <div className="loading">
                <img
                    src="https://bandhanbank.com/themes/customs/bandhan_bank/images/branch-locator/loadersr.gif"
                    alt="No Results Found"
                />
            </div>
        );
    }

    if (allTvShows.length === 0) {
        return (
            <div className="noResults"><img src="https://ottcloudserver.com/assets/templates/labflix/images/no-results.png" alt="No Results Found" /></div>
        );
    }

    return (
        <div className="tvShowsWrapper">
            <div className="filterContainer">
                <p>Explore TV Shows</p>
                <div className="selectDiv">
                    <select onChange={handleGenreChange} value={selectedGenre}>
                        <option value="">Select Genres</option>
                        <option value="10759">Action & Adventure</option>
                        <option value="16">Animation</option>
                        <option value="35">Comedy</option>
                        <option value="80">Crime</option>
                        {/* Add more genres as needed */}
                    </select>
                    <select onChange={handleSortChange} value={sortOrder}>
                        <option value="">Sort By</option>
                        <option value="popularity.asc">Popularity: Low to High</option>
                        <option value="popularity.desc">Popularity: High to Low</option>
                        <option value="vote_average.asc">Rating: Low to High</option>
                        <option value="vote_average.desc">Rating: High to Low</option>
                    </select>
                </div>
            </div>
            <div className="tvShowsContainer">
                {allTvShows.map(el => (
                    <SingleMediaCard key={el.id} el={el} imageSrc={baseUrl + size + el.poster_path} />
                ))}
            </div>
            {hasMoreTVShows && <div>Loading more TV Shows...</div>}
        </div>
    );
};

export default TvShows;