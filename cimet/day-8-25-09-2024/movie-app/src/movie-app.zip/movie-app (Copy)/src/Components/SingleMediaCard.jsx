import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import "../Styles/SingleMediaCard.css";

const SingleMediaCard = ({ el, imageSrc }) => {
    const navigate = useNavigate();
    const location = useLocation();
    const mediaType = location.pathname === "/tvshows" ? "tv" : "movie";

    const handleClick = () => {
        localStorage.setItem("mediaType", JSON.stringify(mediaType));
        navigate(`/${el.id}`);
    }

    const rating = el.vote_average ? el.vote_average : 0;

    return (
        <div className="singleMediaCardWrapper" onClick={handleClick} key={el.id}>
            <img
                src={imageSrc || "https://movix-app-murex.vercel.app/assets/no-poster-4xa9LmsT.png"}
                alt="movieImage"
                onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = "https://movix-app-murex.vercel.app/assets/no-poster-4xa9LmsT.png";
                }}
            />
            <div className='singleMediaContentWrapper'>
                <div>
                    <h3>{el.original_title || el.name}</h3>
                    <p>{el.release_date || el.first_air_date}</p>
                </div>
                <div className="rating">
                    <CircularProgressbar
                        value={rating * 10}
                        text={`${rating.toFixed(1)}`}
                        background
                        styles={{
                            path: { stroke: 'green' },
                            text: { fill: 'black', fontSize: '27px', fontWeight: 500 },
                            trail: { stroke: '#fff' },
                            background: { fill: "white" }
                        }}
                    />
                </div>
            </div>
        </div >
    )
}

export default SingleMediaCard;