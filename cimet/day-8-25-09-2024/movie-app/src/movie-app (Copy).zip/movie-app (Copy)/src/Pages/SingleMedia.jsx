import React from 'react'

const SingleMedia = () => {
    return (
        <div>

        </div>
    )
}

export default SingleMedia
